ShoxCraft resource pack
Menyu sarlavhasi belgisi: \uE000
3D modellar: assets/minecraft/models/item ichiga (Blockbench).
